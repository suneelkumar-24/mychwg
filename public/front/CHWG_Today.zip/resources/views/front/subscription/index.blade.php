@extends('layouts.front')
@section('title', 'Homeopath Subscription')
@section('css')
    <style>

                #card-button  {
            float: left;
            display: block;
            background: #666EE8;
            color: white;
            box-shadow: 0 7px 14px 0 rgba(49,49,93,0.10),
            0 3px 6px 0 rgba(0,0,0,0.08);
            border-radius: 4px;
            border: 0;
            margin-top: 20px;
            font-size: 15px;
            font-weight: 400;
            width: 100%;
            height: 45px;
            line-height: 38px;
            outline: none;
            cursor: pointer;
        }

        #card-button:focus {
            background: #555ABF;
        }

        #card-button:active {
            background: #43458B;
        }

        height-page
        {
            height: 100%;
        }
        .row-eq-height {
            display: -webkit-box;
            display: -webkit-flex;
            display: -ms-flexbox;
            display:         flex;
            height: 100vh;
        }
        .card-payment
        {
            box-shadow: 15px 0 30px 0 rgba(0,0,0,.38);
            border: 0px;
            border-radius: 0px !important;
        }
        /* Blue outline on focus */

        .group {
            background: white;
            box-shadow: 0 7px 14px 0 rgba(49,49,93,0.10),
            0 3px 6px 0 rgba(0,0,0,0.08);
            border-radius: 4px;
            margin-bottom: 20px;
        }

        label {
            position: relative;
            color: #8898AA;
            font-weight: 300;
            height: 40px;
            line-height: 40px;
            margin-left: 20px;
            display: flex;
            flex-direction: row;
        }

        .group label:not(:last-child) {
            border-bottom: 1px solid #F0F5FA;
        }

        label > span {
            width: 80px;
            text-align: right;
            margin-right: 20px;
        }

        .field {
            background: transparent;
            font-weight: 300;
            border: 0;
            color: #31325F;
            outline: none;
            flex: 1;
            padding-right: 10px;
            padding-left: 10px;
            padding-top: 10px;
            cursor: text;
            font-weight: 400;
        }

        .field::-webkit-input-placeholder { color: #CFD7E0; }
        .field::-moz-placeholder { color: #CFD7E0; }



        .outcome {
            float: left;
            width: 100%;
            padding-top: 8px;
            min-height: 24px;
            text-align: center;
        }

        .success, .error {
            display: none;
            font-size: 13px;
        }

        .success.visible, .error.visible {
            display: inline;
        }

        .error {
            color: #E4584C;
        }

        .success {
            color: #666EE8;
        }

        .success .token {
            font-weight: 500;
            font-size: 13px;
        }


    </style>
@endsection


@section('content')

<header>
    <div class="wrapper">
        <div id="header_content" style="background:#dcf2fa 50% center;background-size: cover;">
            @include('front.components.navbar')
        </div>
    </div>
</header>

<section style="background:#F9F9F9;" class="py-5 subscription_page">
    <div class="container py-3 bg-white">
        
        <div class="row">
            <div class="col-sm-12 text-right px-5">
                <a href="{{ route('index') }}">Cancel and return to website</a>
            </div>
            <div class="col-lg-7 col-sm-6 mt-4 px-5">
                <div class="clearfix">
                    <div class="float-left">                    
                        <h5 class="text-info font-weight-bold">$354.43 CAD</h5>
                        <h3 class="font-weight-bold">Homeopath Package</h3>
                    </div>
                    <div class="float-right">
                        30 Days Trial
                    </div>
                </div>
                <h4 class="font-weight-bold mt-3">myClinic (Clinic Management Platform)</h4>
                <small>Run your clinic on the fastest growing homeopath platform that ensures your business</small>
                <div class="jumbotron p-2 font-weight-bold mt-3">Closed access - Ontario residents only (must be registered ba a regulatory board in Ontario)</div>
                <h5 class="font-weight-bold">Advocacy Program (Social Platform) - <span class="text-info">$4.99 CAD/m</span></h5>
                <small>Social health platform dedicated to a community driven by <br> holistic health solutions and alternative healthcare.</small>
            </div>
            <div class="col-lg-5 col-sm-6 mt-4 px-5">
                <div class="card border-0 jumbotron p-1 payment_card">
                    <div class="card-body">
                        <h5 class="font-weight-bold">Order Recap</h5>
                        <div class="clearfix">
                            <div class="float-left">
                                <p>Homeopath Package (Yearly Subscription)</p>
                                <small>This package will automatically renew the <br>following year on the date of purchase.</small>

                            </div>
                            <div class="float-right">$4343</div>

                            <div class="float-left mt-4">
                                <p>Advocacy Program</p>

                            </div>
                            <div class="float-right mt-4">$0.00</div>
                        </div>
                        <hr>
                        <div class="clearfix">
                            <div class="float-left">
                                <p>Taxes</p>
                                <small>HST 13%</small>

                            </div>
                            <div class="float-right">$49.99</div>
                        </div>
                        <hr>
                        <div class="clearfix mb-3">
                            <div class="float-left">
                                <p>Total</p>

                            </div>
                            <div class="float-right text-info font-weight-bold">$433.80</div>
                        </div>
                        <small>All amounts are in CAD</small>
                        <div class="float-right">
                            <button class="btn btn-sm btn-info p-1" data-toggle="modal" data-target="#subscriptionModal">Subscribe</button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        
    </div>
</section>



<div class="modal fade" id="subscriptionModal">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Homeopath Subscription</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
                                <form action="{{ route('create.subscription') }}" method="post" id="payment-form">
                        @csrf
                        <input type="hidden" name="plan" value="{{ env('STRIPE_PLAN') }}" />
                        <div class="group">
                            <label>
                                <span class="card-none">Name</span>
                                <input id="name" class="field" autocomplete="on" placeholder="Jane Doe" required />
                            </label>
                            <label>
                                <span class="card-align card-none">Details</span>
                                <div id="card-element" class="field"></div>
                            </label>
                        </div>
                        <div class="field-set mb-3"> @if(config('services.recaptcha.key')) 
                            <div class="g-recaptcha" data-sitekey="{{config('services.recaptcha.key')}}">
                            </div> @endif </div>
                        <button type="submit" id="card-button" data-secret="{{ $intent->client_secret }}">Start Subscription</button>
                        <div id="card-errors" class="error text-danger"></div>
                        <small><em>No payments will be charged for 30 days after subscription</em></small>
                    </form>
      </div>
    </div>
  </div>
</div>

@endsection



@section('js')
<script src="https://js.stripe.com/v3/"></script>
<script>
    toastr.options = {
        "timeOut": "10000",
    }
</script>

<script>
    var style = {
        base: {
            color: '#32325d',
            lineHeight: '18px',
            fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
            fontSmoothing: 'antialiased',
            fontSize: '16px',
            '::placeholder': {
                color: '#aab7c4'
            }
        },
        invalid: {
            color: '#fa755a',
            iconColor: '#fa755a'
        }
    };
    const stripe = Stripe('{{ env('STRIPE_KEY') }}', { locale: 'en' });
    const elements = stripe.elements(); // Create an instance of Elements.
    const cardElement = elements.create('card', { style: style }); // Create an instance of the card Element.
    const cardButton = document.getElementById('card-button');
    const clientSecret = cardButton.dataset.secret;


    cardElement.mount('#card-element');

    // Handle real-time validation errors from the card Element.
    cardElement.addEventListener('change', function(event) {
        var displayError = document.getElementById('card-errors');
        if (event.error) {
            displayError.textContent = event.error.message;
        } else {
            displayError.textContent = '';
        }
    });

    // Handle form submission.
    var form = document.getElementById('payment-form');

    form.addEventListener('submit', function(event) {
        
        event.preventDefault();
        document.getElementById("card-button").disabled = true;
        document.getElementById("card-button").textContent = 'Loading...';
        stripe
            .handleCardSetup(clientSecret, cardElement, {
                payment_method_data: {
                    //billing_details: { name: cardHolderName.value }
                }
            })
            .then(function(result) {

                if (result.error) {
                    toastr.error(result.error.message);
                    document.getElementById("card-button").textContent = 'Start trial';
                    document.getElementById("card-button").disabled = false;
                    var errorElement = document.getElementById('card-errors');
                    errorElement.textContent = result.error.message;
                } else {

                    // Send the Payment Method to your server.
                    stripeTokenHandler(result.setupIntent.payment_method);
                }
            });
    });

    // Submit the form with the Payment Method.
    function stripeTokenHandler(paymentMethod) {
        // Insert the Payment Method into the form so it gets submitted to the server
        var form = document.getElementById('payment-form');
        var hiddenInput = document.createElement('input');
        hiddenInput.setAttribute('type', 'hidden');
        hiddenInput.setAttribute('name', 'paymentMethod');
        hiddenInput.setAttribute('value', paymentMethod);
        form.appendChild(hiddenInput);
        // Submit the form
        form.submit();
    }
</script>

@endsection