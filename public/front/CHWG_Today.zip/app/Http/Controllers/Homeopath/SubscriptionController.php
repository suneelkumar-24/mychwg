<?php

namespace App\Http\Controllers\Homeopath;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Models\User;
use App\Models\Subscription;
use Carbon\Carbon;

class SubscriptionController extends Controller
{

    protected $stripe;

    public function __construct()
    {
        $this->stripe = new \Stripe\StripeClient(env('STRIPE_SECRET'));
    }

    public function subscriptionPayment()
    {
        $intent = auth()->user()->createSetupIntent();
        return view('front.subscription.index', get_defined_vars());
    }

    public function createSubscription(Request $request)
    {
        

        try
        {
            $user = auth()->user();
            $paymentMethod = $request->paymentMethod;
            $sub=Subscription::where('user_id',auth()->user()->id)->get();
            if($sub!==null)
            {
                foreach($sub as $subsc)
                {
                    $subsc->delete();
                }
            }

            $user->createOrGetStripeCustomer();
            $user->updateDefaultPaymentMethod($paymentMethod);
            
            $subscription=$user->newSubscription('default', env('YEARLY_PLAN'))
                 ->create($paymentMethod, [
                    'email' => $user->email,
                ]);
                
            $stripe = new \Stripe\StripeClient(
                env('STRIPE_SECRET')
            );

        
            

                    
            return redirect()->route('redirect.dashboard')->with('message', 'Welcome to Dashboard, Your subscription has been created.');

        }
        catch (\Exception $e)
        {
            $error = $e->getMessage();
             
            return back()->withError($error);
        }



    }



    public function subscriptionCancel()
    {

        Auth::user()->subscription('default')->cancelNow();
        return redirect()->route('index')->with('message', 'Subscription has been Canceled at CHWG.');
    }


}
